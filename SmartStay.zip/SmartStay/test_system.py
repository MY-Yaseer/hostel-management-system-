#!/usr/bin/env python3
"""
Comprehensive automated test suite for SmartStay Hostel Management System.
Configured for:
- College: SHRIDEVI Degree College
- Hostel: Kings and Queen Hostel
- Main Administrator: Bhagya
- Warden: Parvathi
- Staff: Bhargavi
- Students (exact order): Abhilasha, Harika, Chandan, Santosh, Lekhan, Yogi
"""

import unittest
from app import app
from config import get_db_connection

class SmartStayTestCase(unittest.TestCase):
    def setUp(self):
        self.app = app
        self.app.config['TESTING'] = True
        self.client = self.app.test_client()

    def test_01_landing_page(self):
        """Test public landing page and live database metrics with SHRIDEVI Degree College branding."""
        response = self.client.get('/')
        self.assertEqual(response.status_code, 200)
        self.assertIn(b'SmartStay', response.data)
        self.assertIn(b'SHRIDEVI Degree College', response.data)
        self.assertIn(b'Kings and Queen Hostel', response.data)
        print("[PASS] 01: Landing page rendered with SHRIDEVI Degree College & Kings and Queen Hostel branding.")

    def test_02_admin_authentication_bhagya(self):
        """Test admin login for Bhagya."""
        # Incorrect credentials
        res_fail = self.client.post('/admin/login', data={'username': 'admin', 'password': 'WrongPassword'}, follow_redirects=True)
        self.assertIn(b'Invalid administrator credentials', res_fail.data)

        # Correct credentials for Bhagya
        res_ok = self.client.post('/admin/login', data={'username': 'admin', 'password': 'Admin@123'}, follow_redirects=True)
        self.assertEqual(res_ok.status_code, 200)
        self.assertIn(b'Bhagya', res_ok.data)
        self.assertIn(b'Administrator Overview', res_ok.data)
        print("[PASS] 02: Admin authentication verified for Bhagya.")

    def test_03_role_isolation_security(self):
        """Test RBAC security: student (Abhilasha) cannot access admin or staff dashboards."""
        # Login as student Abhilasha
        self.client.post('/student/login', data={'username': 'STU20260001', 'password': 'Student@123'}, follow_redirects=True)

        # Try to access Admin Dashboard
        admin_res = self.client.get('/admin/dashboard', follow_redirects=True)
        self.assertIn(b'Access denied', admin_res.data)

        # Try to access Staff Dashboard
        staff_res = self.client.get('/staff/dashboard', follow_redirects=True)
        self.assertIn(b'Access denied', staff_res.data)
        print("[PASS] 03: RBAC security verified (Student locked out of Admin & Staff portals).")

    def test_04_student_roommates_abhilasha_harika(self):
        """Test student (Abhilasha) views room Q-101 and fellow roommate Harika."""
        self.client.post('/student/login', data={'username': 'STU20260001', 'password': 'Student@123'}, follow_redirects=True)
        res = self.client.get('/student/room_details')
        self.assertEqual(res.status_code, 200)
        self.assertIn(b'Room Q-101', res.data)
        self.assertIn(b'Harika', res.data) # Fellow roommate
        print("[PASS] 04: Student room-sharing verified (Abhilasha and Harika in Room Q-101).")

    def test_05_student_roommates_chandan_santosh(self):
        """Test student (Chandan) views room K-101 and fellow roommate Santosh."""
        self.client.post('/student/login', data={'username': 'STU20260003', 'password': 'Student@123'}, follow_redirects=True)
        res = self.client.get('/student/room_details')
        self.assertEqual(res.status_code, 200)
        self.assertIn(b'Room K-101', res.data)
        self.assertIn(b'Santosh', res.data) # Fellow roommate
        print("[PASS] 05: Student room-sharing verified (Chandan and Santosh in Room K-101).")

    def test_06_staff_bhargavi_review_and_approve_request(self):
        """Test staff (Bhargavi) logging in, reviewing ticket, and approving with remarks."""
        self.client.post('/staff/login', data={'username': 'bhargavi', 'password': 'Staff@123'}, follow_redirects=True)
        
        # Get list of requests
        res = self.client.get('/staff/requests')
        self.assertEqual(res.status_code, 200)
        self.assertIn(b'Ceiling Fan Regulator', res.data)

        # Find the request ID from DB
        conn = get_db_connection()
        try:
            with conn.cursor() as cur:
                cur.execute("SELECT id FROM student_requests WHERE title LIKE '%Ceiling Fan Regulator%' ORDER BY id DESC LIMIT 1")
                req_row = cur.fetchone()
                req_id = req_row['id']
        finally:
            conn.close()

        # Approve ticket
        proc_res = self.client.post(f'/staff/requests/{req_id}/process', data={
            'status': 'APPROVED',
            'staff_remarks': 'Maintenance team assigned by Bhargavi.'
        }, follow_redirects=True)
        self.assertEqual(proc_res.status_code, 200)
        self.assertIn(b'Ticket status updated to APPROVED', proc_res.data)
        print("[PASS] 06: Staff ticket review and approval workflow verified for Bhargavi.")

    def test_07_warden_parvathi_login(self):
        """Test warden (Parvathi) logging into operations console."""
        res = self.client.post('/staff/login', data={'username': 'parvathi', 'password': 'Warden@123'}, follow_redirects=True)
        self.assertEqual(res.status_code, 200)
        self.assertIn(b'Parvathi', res.data)
        self.assertIn(b'Operations Dashboard', res.data or b'Hostel Operations')
        print("[PASS] 07: Warden login verified for Parvathi.")

    def test_08_room_allocation_and_transfer(self):
        """Test staff (Bhargavi) viewing bed occupancy grid and transferring student bed allocation."""
        # Staff Bhargavi login
        self.client.post('/staff/login', data={'username': 'bhargavi', 'password': 'Staff@123'}, follow_redirects=True)

        # GET room allocation page
        alloc_get = self.client.get('/staff/room_allocation')
        self.assertEqual(alloc_get.status_code, 200)
        self.assertIn(b'Interactive Room Sharing', alloc_get.data)
        self.assertIn(b'Bed Allocation & Room Management', alloc_get.data)

        # Get Chandan's ID (student_id STU20260003)
        conn = get_db_connection()
        try:
            with conn.cursor() as cur:
                cur.execute("SELECT id FROM students WHERE student_id = 'STU20260003'")
                chandan_id = cur.fetchone()['id']
                cur.execute("SELECT id FROM rooms WHERE room_number = 'K-102'")
                k102_id = cur.fetchone()['id']
                cur.execute("SELECT id FROM rooms WHERE room_number = 'K-201'")
                k201_id = cur.fetchone()['id']
                cur.execute("SELECT id FROM rooms WHERE room_number = 'K-101'")
                k101_id = cur.fetchone()['id']
        finally:
            conn.close()

        # Attempt to transfer Chandan to FULL room K-102 -> Must block and show capacity alert
        full_res = self.client.post('/staff/room_allocation', data={
            'student_id': str(chandan_id),
            'target_room_id': str(k102_id)
        }, follow_redirects=True)
        self.assertEqual(full_res.status_code, 200)
        self.assertIn(b'already at full capacity', full_res.data)

        # Transfer Chandan to available room K-201 -> Must succeed
        transfer_res = self.client.post('/staff/room_allocation', data={
            'student_id': str(chandan_id),
            'target_room_id': str(k201_id)
        }, follow_redirects=True)
        self.assertEqual(transfer_res.status_code, 200)
        self.assertIn(b'successfully allocated to Room K-201', transfer_res.data)

        # Re-transfer Chandan back to K-101
        restore_res = self.client.post('/staff/room_allocation', data={
            'student_id': str(chandan_id),
            'target_room_id': str(k101_id)
        }, follow_redirects=True)
        self.assertEqual(restore_res.status_code, 200)
        self.assertIn(b'successfully allocated to Room K-101', restore_res.data)
        print("[PASS] 08: Room bed allocation, capacity enforcement, and transfer workflow verified for Bhargavi.")

if __name__ == '__main__':
    unittest.main()
