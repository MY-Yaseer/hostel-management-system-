import os
from datetime import timedelta
import pymysql
import pymysql.cursors

class Config:
    """Application configuration for SmartStay Hostel Management System."""
    SECRET_KEY = os.environ.get('SECRET_KEY', 'smartstay_production_secret_key_8923482348923489')
    
    # MySQL Database Connection Settings (XAMPP Default)
    DB_HOST = os.environ.get('DB_HOST', '127.0.0.1')
    DB_PORT = int(os.environ.get('DB_PORT', 3306))
    DB_USER = os.environ.get('DB_USER', 'root')
    DB_PASSWORD = os.environ.get('DB_PASSWORD', '')
    DB_NAME = os.environ.get('DB_NAME', 'smartstay_hostel')
    
    # Session Settings
    PERMANENT_SESSION_LIFETIME = timedelta(hours=8)
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = 'Lax'

def get_db_connection():
    """
    Establish and return a PyMySQL database connection with DictCursor.
    DictCursor enables accessing column values by column name.
    """
    return pymysql.connect(
        host=Config.DB_HOST,
        port=Config.DB_PORT,
        user=Config.DB_USER,
        password=Config.DB_PASSWORD,
        database=Config.DB_NAME,
        cursorclass=pymysql.cursors.DictCursor,
        autocommit=False,
        charset='utf8mb4'
    )
