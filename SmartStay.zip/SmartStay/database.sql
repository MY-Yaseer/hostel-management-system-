-- SmartStay Hostel Management System Database Schema
-- Customized for SHRIDEVI Degree College - Kings and Queen Hostel
-- Compatible with MariaDB / MySQL on XAMPP

CREATE DATABASE IF NOT EXISTS smartstay_hostel CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE smartstay_hostel;

-- Disable foreign key checks during initialization
SET FOREIGN_KEY_CHECKS = 0;

-- 1. Hostels Table
DROP TABLE IF EXISTS hostels;
CREATE TABLE hostels (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(120) NOT NULL,
    hostel_type ENUM('Boys', 'Girls', 'Co-ed') NOT NULL DEFAULT 'Boys',
    total_floors INT NOT NULL DEFAULT 3,
    address TEXT NOT NULL,
    contact_number VARCHAR(20) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- 2. Rooms Table
DROP TABLE IF EXISTS rooms;
CREATE TABLE rooms (
    id INT AUTO_INCREMENT PRIMARY KEY,
    hostel_id INT NOT NULL,
    room_number VARCHAR(20) NOT NULL,
    floor INT NOT NULL DEFAULT 1,
    room_type VARCHAR(50) NOT NULL DEFAULT 'Three Sharing',
    capacity INT NOT NULL DEFAULT 3,
    monthly_fee DECIMAL(10, 2) NOT NULL DEFAULT 5000.00,
    status ENUM('available', 'full', 'maintenance') NOT NULL DEFAULT 'available',
    description VARCHAR(255) DEFAULT 'Furnished student room with study desks and storage',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_hostel_room (hostel_id, room_number),
    CONSTRAINT fk_room_hostel FOREIGN KEY (hostel_id) REFERENCES hostels(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- 3. Admins Table
DROP TABLE IF EXISTS admins;
CREATE TABLE admins (
    id INT AUTO_INCREMENT PRIMARY KEY,
    admin_id VARCHAR(20) NOT NULL UNIQUE,
    username VARCHAR(50) NOT NULL UNIQUE,
    email VARCHAR(100) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    phone VARCHAR(20) DEFAULT '+91 98888 77777',
    is_super_admin TINYINT(1) NOT NULL DEFAULT 1,
    status ENUM('active', 'inactive') NOT NULL DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- 4. Wardens Table
DROP TABLE IF EXISTS wardens;
CREATE TABLE wardens (
    id INT AUTO_INCREMENT PRIMARY KEY,
    warden_id VARCHAR(20) NOT NULL UNIQUE,
    hostel_id INT NOT NULL,
    username VARCHAR(50) NOT NULL UNIQUE,
    email VARCHAR(100) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    status ENUM('active', 'inactive') NOT NULL DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_warden_hostel FOREIGN KEY (hostel_id) REFERENCES hostels(id) ON DELETE RESTRICT
) ENGINE=InnoDB;

-- 5. Staff Table
DROP TABLE IF EXISTS staff;
CREATE TABLE staff (
    id INT AUTO_INCREMENT PRIMARY KEY,
    staff_id VARCHAR(20) NOT NULL UNIQUE,
    hostel_id INT DEFAULT NULL,
    username VARCHAR(50) NOT NULL UNIQUE,
    email VARCHAR(100) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    designation VARCHAR(100) NOT NULL DEFAULT 'Hostel Operations Supervisor',
    status ENUM('pending', 'active', 'inactive', 'suspended') NOT NULL DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_staff_hostel FOREIGN KEY (hostel_id) REFERENCES hostels(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- 6. Permissions Table
DROP TABLE IF EXISTS permissions;
CREATE TABLE permissions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    code VARCHAR(50) NOT NULL UNIQUE,
    name VARCHAR(100) NOT NULL,
    description VARCHAR(255) NOT NULL
) ENGINE=InnoDB;

-- 7. Staff Permissions Junction Table
DROP TABLE IF EXISTS staff_permissions;
CREATE TABLE staff_permissions (
    staff_id INT NOT NULL,
    permission_id INT NOT NULL,
    PRIMARY KEY (staff_id, permission_id),
    CONSTRAINT fk_sp_staff FOREIGN KEY (staff_id) REFERENCES staff(id) ON DELETE CASCADE,
    CONSTRAINT fk_sp_permission FOREIGN KEY (permission_id) REFERENCES permissions(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- 8. Students Table
DROP TABLE IF EXISTS students;
CREATE TABLE students (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id VARCHAR(20) NOT NULL UNIQUE,
    hostel_id INT NOT NULL,
    room_id INT DEFAULT NULL,
    username VARCHAR(50) NOT NULL UNIQUE,
    email VARCHAR(100) NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    gender ENUM('Male', 'Female', 'Other') NOT NULL DEFAULT 'Male',
    course VARCHAR(120) NOT NULL DEFAULT 'BCA - SHRIDEVI Degree College',
    parent_name VARCHAR(100) NOT NULL,
    parent_phone VARCHAR(20) NOT NULL,
    address TEXT NOT NULL,
    emergency_contact VARCHAR(20) NOT NULL,
    must_change_password TINYINT(1) NOT NULL DEFAULT 1,
    status ENUM('active', 'inactive', 'graduated') NOT NULL DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_student_hostel FOREIGN KEY (hostel_id) REFERENCES hostels(id) ON DELETE RESTRICT,
    CONSTRAINT fk_student_room FOREIGN KEY (room_id) REFERENCES rooms(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- 9. Room Allocations History Table
DROP TABLE IF EXISTS room_allocations;
CREATE TABLE room_allocations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    room_id INT NOT NULL,
    allocated_by VARCHAR(50) NOT NULL DEFAULT 'System Admin',
    allocated_role VARCHAR(20) NOT NULL DEFAULT 'admin',
    start_date DATE NOT NULL,
    end_date DATE DEFAULT NULL,
    status ENUM('active', 'transferred', 'vacated') NOT NULL DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_alloc_student FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
    CONSTRAINT fk_alloc_room FOREIGN KEY (room_id) REFERENCES rooms(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- 10. Fee Records Table
DROP TABLE IF EXISTS fee_records;
CREATE TABLE fee_records (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    academic_term VARCHAR(80) NOT NULL DEFAULT 'Academic Term 2026-27 (Sem 1)',
    total_amount DECIMAL(10, 2) NOT NULL DEFAULT 30000.00,
    paid_amount DECIMAL(10, 2) NOT NULL DEFAULT 0.00,
    due_date DATE NOT NULL,
    status ENUM('pending', 'partial', 'paid', 'overdue') NOT NULL DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_fee_student FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- 11. Fee Payments Table
DROP TABLE IF EXISTS fee_payments;
CREATE TABLE fee_payments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    receipt_number VARCHAR(30) NOT NULL UNIQUE,
    fee_record_id INT NOT NULL,
    student_id INT NOT NULL,
    amount_paid DECIMAL(10, 2) NOT NULL,
    payment_mode ENUM('Cash', 'UPI / Bank Transfer', 'Cheque', 'Demand Draft') NOT NULL DEFAULT 'UPI / Bank Transfer',
    payment_date DATE NOT NULL,
    recorded_by VARCHAR(100) NOT NULL,
    recorded_role VARCHAR(20) NOT NULL,
    remarks VARCHAR(255) DEFAULT 'Hostel installment payment',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_pay_record FOREIGN KEY (fee_record_id) REFERENCES fee_records(id) ON DELETE CASCADE,
    CONSTRAINT fk_pay_student FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- 12. Student Requests & Complaints Table
DROP TABLE IF EXISTS student_requests;
CREATE TABLE student_requests (
    id INT AUTO_INCREMENT PRIMARY KEY,
    request_id VARCHAR(20) NOT NULL UNIQUE,
    student_id INT NOT NULL,
    category ENUM('room_change', 'maintenance', 'hostel_complaint', 'general') NOT NULL DEFAULT 'general',
    title VARCHAR(150) NOT NULL,
    description TEXT NOT NULL,
    preferred_room_type VARCHAR(50) DEFAULT NULL,
    priority ENUM('low', 'medium', 'high') NOT NULL DEFAULT 'medium',
    status ENUM('PENDING', 'APPROVED', 'REJECTED', 'COMPLETED') NOT NULL DEFAULT 'PENDING',
    staff_remarks TEXT DEFAULT NULL,
    processed_by VARCHAR(100) DEFAULT NULL,
    processed_role VARCHAR(20) DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_req_student FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- 13. Announcements Table
DROP TABLE IF EXISTS announcements;
CREATE TABLE announcements (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(150) NOT NULL,
    message TEXT NOT NULL,
    target_role ENUM('all', 'students', 'staff') NOT NULL DEFAULT 'all',
    hostel_id INT DEFAULT NULL,
    posted_by VARCHAR(100) NOT NULL,
    posted_role VARCHAR(20) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_ann_hostel FOREIGN KEY (hostel_id) REFERENCES hostels(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- 14. Activity Logs Table
DROP TABLE IF EXISTS activity_logs;
CREATE TABLE activity_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT DEFAULT NULL,
    custom_id VARCHAR(30) DEFAULT NULL,
    role VARCHAR(20) NOT NULL,
    action VARCHAR(100) NOT NULL,
    details TEXT DEFAULT NULL,
    ip_address VARCHAR(45) DEFAULT '127.0.0.1',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Re-enable foreign key checks
SET FOREIGN_KEY_CHECKS = 1;

-- ==========================================================
-- SEED DATA: SHRIDEVI DEGREE COLLEGE - KINGS & QUEEN HOSTEL
-- EXACT ROLES & NAMES ORDER:
-- Main Administrator : Bhagya
-- Warden             : Parvathi
-- Staff              : Bhargavi
-- Students           : Abhilasha, Harika, Chandan, Santosh, Lekhan, Yogi
-- ==========================================================

-- Standard Staff Permissions
INSERT INTO permissions (id, code, name, description) VALUES
(1, 'create_student', 'Register Students', 'Allows staff to register new students and auto-generate credentials'),
(2, 'allocate_rooms', 'Allocate / Transfer Rooms', 'Allows staff to assign beds, move students and manage occupancy'),
(3, 'manage_fees', 'Manage Fee Records', 'Allows staff to view fees and record manual payments'),
(4, 'process_requests', 'Review Student Requests', 'Allows staff to approve or reject student complaints & room change requests'),
(5, 'generate_reports', 'Generate Reports', 'Allows staff to view and export student and occupancy summary data');

-- Hostels for SHRIDEVI Degree College
INSERT INTO hostels (id, name, hostel_type, total_floors, address, contact_number) VALUES
(1, 'Kings Hostel (Boys Block) - SHRIDEVI Degree College', 'Boys', 4, 'SHRIDEVI Degree College Campus, NH-4, Tumakuru, Karnataka', '+91 98801 12345'),
(2, 'Queens Hostel (Girls Block) - SHRIDEVI Degree College', 'Girls', 4, 'SHRIDEVI Degree College Campus, NH-4, Tumakuru, Karnataka', '+91 98801 67890');

-- Rooms for Kings Hostel (Boys)
INSERT INTO rooms (id, hostel_id, room_number, floor, room_type, capacity, monthly_fee, status, description) VALUES
(1, 1, 'K-101', 1, 'Three Sharing', 3, 5000.00, 'available', 'Ground floor deluxe room with attached study desks and Wi-Fi'),
(2, 1, 'K-102', 1, 'Double Sharing', 2, 7000.00, 'available', 'Ground floor double occupancy room with private balcony'),
(3, 1, 'K-201', 2, 'Three Sharing', 3, 5000.00, 'available', 'Second floor room overlooking campus sports grounds'),
(4, 1, 'K-202', 2, 'Single Sharing', 1, 11000.00, 'available', 'Quiet private scholar suite');

-- Rooms for Queens Hostel (Girls)
INSERT INTO rooms (id, hostel_id, room_number, floor, room_type, capacity, monthly_fee, status, description) VALUES
(5, 2, 'Q-101', 1, 'Three Sharing', 3, 5500.00, 'available', 'Ground floor garden-facing room with study area & personal wardrobes'),
(6, 2, 'Q-102', 1, 'Double Sharing', 2, 7500.00, 'available', 'First floor premium double room with attached washroom'),
(7, 2, 'Q-201', 2, 'Three Sharing', 3, 5500.00, 'available', 'Second floor well-ventilated room with reading alcove'),
(8, 2, 'Q-202', 2, 'Single Sharing', 1, 12000.00, 'available', 'Private premium executive single room');

-- Main Administrator: Bhagya
-- Password: Admin@123
INSERT INTO admins (id, admin_id, username, email, password_hash, full_name, phone, is_super_admin, status) VALUES
(1, 'ADM0001', 'admin', 'bhagya.admin@shridevi.edu.in', 'scrypt:32768:8:1$j0mrBiEtlCShuOY4$28048f807ef848b0dd8df8fc0b1ea0232423694f2897e0d3b3a37d9c7bd97dd568c923c182342eebb8378fdce877f7b099acda0ab629d277aec7fbb74ba526fa', 'Bhagya', '+91 98888 77777', 1, 'active');

-- Warden: Parvathi
-- Password: Warden@123
INSERT INTO wardens (id, warden_id, hostel_id, username, email, password_hash, full_name, phone, status) VALUES
(1, 'WRD0001', 2, 'parvathi', 'parvathi.warden@shridevi.edu.in', 'scrypt:32768:8:1$L3CZiJnYaVaXbc0R$4434df2a8458d51f57dcb7d89877358a2d4bb1dfe9234116cc23d161b2dba95dc05b3f7ba34ba9869e67bbf8dcbe6ca3941d9d04dcb2a6ac6afbd71d83e87d22', 'Parvathi', '+91 98765 11002', 'active');

-- Staff: Bhargavi
-- Password: Staff@123
INSERT INTO staff (id, staff_id, hostel_id, username, email, password_hash, full_name, phone, designation, status) VALUES
(1, 'STF0001', 2, 'bhargavi', 'bhargavi.staff@shridevi.edu.in', 'scrypt:32768:8:1$EfKAiY66TxCqHjVn$17c9f04dcd0574aa265a4df2438fe727fe3aee98f0d2f5fac472300357f0d16c5374d7174e829c9629ed9d2169a42a28f43449004b050fce0b5f997a98ae8e46', 'Bhargavi', '+91 98765 22001', 'Hostel Operations Supervisor', 'active');

-- Assign All Permissions to Staff Bhargavi
INSERT INTO staff_permissions (staff_id, permission_id) VALUES
(1, 1), (1, 2), (1, 3), (1, 4), (1, 5);

-- 6 Students in the exact requested order:
-- 1. Abhilasha
-- 2. Harika
-- 3. Chandan
-- 4. Santosh
-- 5. Lekhan
-- 6. Yogi
-- Password for all students: Student@123

-- 1. Student: Abhilasha (Queens Hostel, Room Q-101)
INSERT INTO students (id, student_id, hostel_id, room_id, username, email, password_hash, full_name, phone, gender, course, parent_name, parent_phone, address, emergency_contact, must_change_password, status) VALUES
(1, 'STU20260001', 2, 5, 'STU20260001', 'abhilasha@student.shridevi.edu.in', 'scrypt:32768:8:1$ZkWd1eN8eYo7IFb6$3e3a9a836cfc7e04ab99c0a54d7aefc7d12d3640b1e0ea9008b58780c1f90564e53f515659ca55363752f7e128d9fc5edd274d47436f71fa08d91a69e262d53d', 'Abhilasha', '+91 91234 00001', 'Female', 'BCA - SHRIDEVI Degree College', 'Shankarappa', '+91 98450 11111', 'Sapthagiri Extension, Tumakuru, Karnataka', '+91 91234 00001', 0, 'active');

-- 2. Student: Harika (Queens Hostel, Room Q-101 - Sharing with Abhilasha)
INSERT INTO students (id, student_id, hostel_id, room_id, username, email, password_hash, full_name, phone, gender, course, parent_name, parent_phone, address, emergency_contact, must_change_password, status) VALUES
(2, 'STU20260002', 2, 5, 'STU20260002', 'harika@student.shridevi.edu.in', 'scrypt:32768:8:1$ZkWd1eN8eYo7IFb6$3e3a9a836cfc7e04ab99c0a54d7aefc7d12d3640b1e0ea9008b58780c1f90564e53f515659ca55363752f7e128d9fc5edd274d47436f71fa08d91a69e262d53d', 'Harika', '+91 91234 00002', 'Female', 'BBA - SHRIDEVI Degree College', 'Mallikarjun', '+91 98450 22222', 'Vidyanagar, Davangere, Karnataka', '+91 91234 00002', 0, 'active');

-- 3. Student: Chandan (Kings Hostel, Room K-101)
INSERT INTO students (id, student_id, hostel_id, room_id, username, email, password_hash, full_name, phone, gender, course, parent_name, parent_phone, address, emergency_contact, must_change_password, status) VALUES
(3, 'STU20260003', 1, 1, 'STU20260003', 'chandan@student.shridevi.edu.in', 'scrypt:32768:8:1$ZkWd1eN8eYo7IFb6$3e3a9a836cfc7e04ab99c0a54d7aefc7d12d3640b1e0ea9008b58780c1f90564e53f515659ca55363752f7e128d9fc5edd274d47436f71fa08d91a69e262d53d', 'Chandan', '+91 91234 00003', 'Male', 'B.Sc Computer Science - SHRIDEVI Degree College', 'Govindappa', '+91 98450 33333', 'Gandhi Nagar, Tumakuru, Karnataka', '+91 91234 00003', 0, 'active');

-- 4. Student: Santosh (Kings Hostel, Room K-101 - Sharing with Chandan)
INSERT INTO students (id, student_id, hostel_id, room_id, username, email, password_hash, full_name, phone, gender, course, parent_name, parent_phone, address, emergency_contact, must_change_password, status) VALUES
(4, 'STU20260004', 1, 1, 'STU20260004', 'santosh@student.shridevi.edu.in', 'scrypt:32768:8:1$ZkWd1eN8eYo7IFb6$3e3a9a836cfc7e04ab99c0a54d7aefc7d12d3640b1e0ea9008b58780c1f90564e53f515659ca55363752f7e128d9fc5edd274d47436f71fa08d91a69e262d53d', 'Santosh', '+91 91234 00004', 'Male', 'B.Com - SHRIDEVI Degree College', 'Nagaraj', '+91 98450 44444', 'Kuvempunagar, Shivamogga, Karnataka', '+91 91234 00004', 0, 'active');

-- 5. Student: Lekhan (Kings Hostel, Room K-102)
INSERT INTO students (id, student_id, hostel_id, room_id, username, email, password_hash, full_name, phone, gender, course, parent_name, parent_phone, address, emergency_contact, must_change_password, status) VALUES
(5, 'STU20260005', 1, 2, 'STU20260005', 'lekhan@student.shridevi.edu.in', 'scrypt:32768:8:1$ZkWd1eN8eYo7IFb6$3e3a9a836cfc7e04ab99c0a54d7aefc7d12d3640b1e0ea9008b58780c1f90564e53f515659ca55363752f7e128d9fc5edd274d47436f71fa08d91a69e262d53d', 'Lekhan', '+91 91234 00005', 'Male', 'BCA - SHRIDEVI Degree College', 'Basavaraj', '+91 98450 55555', 'Rajajinagar, Bengaluru, Karnataka', '+91 91234 00005', 0, 'active');

-- 6. Student: Yogi (Kings Hostel, Room K-102 - Sharing with Lekhan)
INSERT INTO students (id, student_id, hostel_id, room_id, username, email, password_hash, full_name, phone, gender, course, parent_name, parent_phone, address, emergency_contact, must_change_password, status) VALUES
(6, 'STU20260006', 1, 2, 'STU20260006', 'yogi@student.shridevi.edu.in', 'scrypt:32768:8:1$ZkWd1eN8eYo7IFb6$3e3a9a836cfc7e04ab99c0a54d7aefc7d12d3640b1e0ea9008b58780c1f90564e53f515659ca55363752f7e128d9fc5edd274d47436f71fa08d91a69e262d53d', 'Yogi', '+91 91234 00006', 'Male', 'BBA - SHRIDEVI Degree College', 'Chandrashekar', '+91 98450 66666', 'Jayanagar, Mysuru, Karnataka', '+91 91234 00006', 0, 'active');

-- Record active room allocations
INSERT INTO room_allocations (student_id, room_id, allocated_by, allocated_role, start_date, status) VALUES
(1, 5, 'Bhagya', 'admin', '2026-08-01', 'active'),
(2, 5, 'Parvathi', 'warden', '2026-08-01', 'active'),
(3, 1, 'Bhargavi', 'staff', '2026-08-01', 'active'),
(4, 1, 'Bhargavi', 'staff', '2026-08-01', 'active'),
(5, 2, 'Parvathi', 'warden', '2026-08-01', 'active'),
(6, 2, 'Bhagya', 'admin', '2026-08-01', 'active');

-- Fee records
INSERT INTO fee_records (id, student_id, academic_term, total_amount, paid_amount, due_date, status) VALUES
(1, 1, 'Academic Term 2026-27 (Sem 1)', 33000.00, 22000.00, '2026-11-30', 'partial'),
(2, 2, 'Academic Term 2026-27 (Sem 1)', 33000.00, 33000.00, '2026-11-30', 'paid'),
(3, 3, 'Academic Term 2026-27 (Sem 1)', 30000.00, 20000.00, '2026-11-30', 'partial'),
(4, 4, 'Academic Term 2026-27 (Sem 1)', 30000.00, 30000.00, '2026-11-30', 'paid'),
(5, 5, 'Academic Term 2026-27 (Sem 1)', 32000.00, 16000.00, '2026-11-30', 'partial'),
(6, 6, 'Academic Term 2026-27 (Sem 1)', 32000.00, 32000.00, '2026-11-30', 'paid');

-- Payment receipts
INSERT INTO fee_payments (receipt_number, fee_record_id, student_id, amount_paid, payment_mode, payment_date, recorded_by, recorded_role, remarks) VALUES
('REC2026001', 1, 1, 22000.00, 'UPI / Bank Transfer', '2026-08-05', 'Bhargavi', 'staff', 'Hostel installment paid via Google Pay'),
('REC2026002', 2, 2, 33000.00, 'Demand Draft', '2026-08-02', 'Bhagya', 'admin', 'Full semester fee paid via Bank DD'),
('REC2026003', 3, 3, 20000.00, 'UPI / Bank Transfer', '2026-08-06', 'Bhargavi', 'staff', 'Online bank transfer via NEFT'),
('REC2026004', 4, 4, 30000.00, 'Cash', '2026-08-03', 'Parvathi', 'warden', 'Full fee cash receipt issued'),
('REC2026005', 5, 5, 16000.00, 'UPI / Bank Transfer', '2026-08-10', 'Bhargavi', 'staff', 'First semester partial payment'),
('REC2026006', 6, 6, 32000.00, 'UPI / Bank Transfer', '2026-08-04', 'Parvathi', 'warden', 'Full installment online payment');

-- Sample Student Request
INSERT INTO student_requests (request_id, student_id, category, title, description, priority, status, staff_remarks, processed_by, processed_role) VALUES
('REQ00001', 1, 'maintenance', 'Ceiling Fan Regulator in Room Q-101', 'The fan regulator knob in room Q-101 is not rotating smoothly.', 'medium', 'APPROVED', 'Electrician scheduled for inspection on Friday morning.', 'Parvathi', 'warden'),
('REQ00002', 3, 'maintenance', 'Study Lamp Switch in Room K-101', 'The desk switch for study lamp 2 is loose.', 'low', 'APPROVED', 'Handyman assigned for service.', 'Bhargavi', 'staff');

-- Sample Announcements for Kings & Queen Hostel - SHRIDEVI Degree College
INSERT INTO announcements (title, message, target_role, hostel_id, posted_by, posted_role) VALUES
('Annual Campus Sanitization & Inspection', 'Please note that facility inspection will take place this Saturday between 10:00 AM and 2:00 PM across both Kings and Queens blocks.', 'all', NULL, 'Bhagya (Administrator)', 'admin'),
('Queens Hostel Study Lounge 24/7 Hours', 'During midterm examinations, the reading hall in Queens Hostel will remain open 24 hours with high-speed campus Wi-Fi.', 'students', 2, 'Parvathi (Warden)', 'warden'),
('Kings Hostel Sports Events', 'Sign-ups for the intra-hostel table tennis and badminton tournaments are open at the warden office.', 'students', 1, 'Bhargavi (Staff)', 'staff');

-- Activity log initial entry
INSERT INTO activity_logs (user_id, custom_id, role, action, details, ip_address) VALUES
(1, 'ADM0001', 'admin', 'SYSTEM_INITIALIZATION', 'Kings and Queen Hostel (SHRIDEVI Degree College) database initialized.', '127.0.0.1');
