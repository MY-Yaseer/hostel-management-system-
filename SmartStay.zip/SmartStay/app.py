#!/usr/bin/env python3
"""
SmartStay - Advanced Hostel Management System
Technology Stack: Python 3 + Flask + PyMySQL (Pure Python) + MySQL (XAMPP)
Design: SaaS Architecture, Multi-Portal RBAC, CSS-only animations and widgets
Zero C/C++ compilers or Node.js dependencies required.
"""

import re
import datetime
from functools import wraps
from flask import (
    Flask, render_template, request, redirect,
    url_for, session, flash, abort, jsonify
)
from werkzeug.security import generate_password_hash, check_password_hash
from config import Config, get_db_connection

app = Flask(__name__)
app.config.from_object(Config)

# ==============================================================================
# Helper & Utility Functions
# ==============================================================================

def log_activity(conn, user_id, custom_id, role, action, details):
    """Record an immutable event into the activity_logs table."""
    try:
        ip = request.remote_addr or '127.0.0.1'
        with conn.cursor() as cur:
            cur.execute("""
                INSERT INTO activity_logs (user_id, custom_id, role, action, details, ip_address)
                VALUES (%s, %s, %s, %s, %s, %s)
            """, (user_id, custom_id, role, action, details, ip))
        conn.commit()
    except Exception as e:
        app.logger.warning(f"Failed to log activity: {e}")

def generate_custom_id(conn, role, year=None):
    """
    Generate auto-incrementing, collision-free custom IDs:
    Admin:   ADM0001, ADM0002...
    Warden:  WRD0001, WRD0002...
    Staff:   STF0001, STF0002...
    Student: STU20260001, STU20260002...
    """
    if year is None:
        year = datetime.datetime.now().year

    with conn.cursor() as cur:
        if role == 'admin':
            cur.execute("SELECT MAX(id) AS max_id FROM admins")
            row = cur.fetchone()
            next_num = (row['max_id'] or 0) + 1
            return f"ADM{next_num:04d}"
        elif role == 'warden':
            cur.execute("SELECT MAX(id) AS max_id FROM wardens")
            row = cur.fetchone()
            next_num = (row['max_id'] or 0) + 1
            return f"WRD{next_num:04d}"
        elif role == 'staff':
            cur.execute("SELECT MAX(id) AS max_id FROM staff")
            row = cur.fetchone()
            next_num = (row['max_id'] or 0) + 1
            return f"STF{next_num:04d}"
        elif role == 'student':
            cur.execute("SELECT MAX(id) AS max_id FROM students")
            row = cur.fetchone()
            next_num = (row['max_id'] or 0) + 1
            return f"STU{year}{next_num:04d}"
        elif role == 'request':
            cur.execute("SELECT MAX(id) AS max_id FROM student_requests")
            row = cur.fetchone()
            next_num = (row['max_id'] or 0) + 1
            return f"REQ{next_num:05d}"
        elif role == 'receipt':
            cur.execute("SELECT MAX(id) AS max_id FROM fee_payments")
            row = cur.fetchone()
            next_num = (row['max_id'] or 0) + 1
            return f"REC{year}{next_num:04d}"
    return None

def check_permission(staff_id, permission_code):
    """
    Check if a staff member has the given permission.
    Wardens and Admins possess operational rights.
    """
    role = session.get('role')
    if role in ['admin', 'warden']:
        return True
    
    conn = get_db_connection()
    try:
        with conn.cursor() as cur:
            cur.execute("""
                SELECT 1 FROM staff_permissions sp
                JOIN permissions p ON sp.permission_id = p.id
                WHERE sp.staff_id = %s AND p.code = %s
            """, (staff_id, permission_code))
            return cur.fetchone() is not None
    finally:
        conn.close()

# ==============================================================================
# Authentication & Access Control Decorators
# ==============================================================================

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session or 'role' not in session:
            flash("Please sign in to access this portal.", "warning")
            return redirect(url_for('index'))
        return f(*args, **kwargs)
    return decorated_function

def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session or session.get('role') != 'admin':
            flash("Access denied. Administrator privileges required.", "danger")
            return redirect(url_for('admin_login'))
        return f(*args, **kwargs)
    return decorated_function

def warden_or_staff_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session or session.get('role') not in ['admin', 'warden', 'staff']:
            flash("Access denied. Staff or warden credentials required.", "danger")
            return redirect(url_for('staff_login'))
        return f(*args, **kwargs)
    return decorated_function

def student_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session or session.get('role') != 'student':
            flash("Access denied. Student portal authorization required.", "danger")
            return redirect(url_for('student_login'))
        return f(*args, **kwargs)
    return decorated_function

# ==============================================================================
# Public Landing & Universal Routes
# ==============================================================================

@app.route('/')
def index():
    """Public showcase landing with portal cards and live database statistics."""
    conn = get_db_connection()
    try:
        with conn.cursor() as cur:
            cur.execute("SELECT COUNT(*) AS count FROM hostels")
            total_hostels = cur.fetchone()['count']

            cur.execute("SELECT COUNT(*) AS count, IFNULL(SUM(capacity), 0) AS total_cap FROM rooms")
            room_row = cur.fetchone()
            total_rooms = room_row['count']
            total_capacity = int(room_row['total_cap'])

            cur.execute("SELECT COUNT(*) AS count FROM students WHERE status = 'active'")
            total_students = cur.fetchone()['count']

            cur.execute("SELECT COUNT(*) AS count FROM students WHERE room_id IS NOT NULL AND status = 'active'")
            occupied_beds = cur.fetchone()['count']

            stats = {
                'total_hostels': total_hostels,
                'total_rooms': total_rooms,
                'total_capacity': total_capacity,
                'total_students': total_students,
                'occupied_beds': occupied_beds,
                'available_beds': max(0, total_capacity - occupied_beds)
            }
        return render_template('index.html', stats=stats)
    finally:
        conn.close()

@app.route('/dashboard')
@login_required
def dashboard():
    """Universal router dispatching user to their respective role dashboard."""
    role = session.get('role')
    if role == 'admin':
        return redirect(url_for('admin_dashboard'))
    elif role in ['staff', 'warden']:
        return redirect(url_for('staff_dashboard'))
    elif role == 'student':
        return redirect(url_for('student_dashboard'))
    return redirect(url_for('index'))

@app.route('/logout')
def logout():
    """Log out active session and return to portal landing."""
    user_id = session.get('user_id')
    custom_id = session.get('custom_id')
    role = session.get('role')

    if user_id:
        conn = get_db_connection()
        try:
            log_activity(conn, user_id, custom_id, role, 'LOGOUT', 'User signed out gracefully.')
        finally:
            conn.close()

    session.clear()
    flash("You have been signed out safely.", "info")
    return redirect(url_for('index'))

# ==============================================================================
# Main Administrator Portal
# ==============================================================================

@app.route('/admin/login', methods=['GET', 'POST'])
def admin_login():
    """Dedicated secure login portal for administrators."""
    if session.get('role') == 'admin':
        return redirect(url_for('admin_dashboard'))

    if request.method == 'POST':
        identifier = request.form.get('username', '').strip()
        password = request.form.get('password', '').strip()

        conn = get_db_connection()
        try:
            with conn.cursor() as cur:
                cur.execute("""
                    SELECT * FROM admins
                    WHERE (username = %s OR admin_id = %s) AND status = 'active'
                """, (identifier, identifier))
                admin = cur.fetchone()

            if admin and check_password_hash(admin['password_hash'], password):
                session.clear()
                session['user_id'] = admin['id']
                session['custom_id'] = admin['admin_id']
                session['role'] = 'admin'
                session['name'] = admin['full_name']
                session['email'] = admin['email']

                log_activity(conn, admin['id'], admin['admin_id'], 'admin', 'ADMIN_LOGIN', 'Administrator authenticated.')
                flash(f"Welcome back, {admin['full_name']}!", "success")
                return redirect(url_for('admin_dashboard'))
            else:
                flash("Invalid administrator credentials or inactive account.", "danger")
        finally:
            conn.close()

    return render_template('admin/login.html')

@app.route('/admin/dashboard')
@admin_required
def admin_dashboard():
    """Master administration console with aggregate telemetry."""
    conn = get_db_connection()
    try:
        with conn.cursor() as cur:
            # Aggregate stats
            cur.execute("SELECT COUNT(*) AS count FROM students")
            total_students = cur.fetchone()['count']

            cur.execute("SELECT COUNT(*) AS count FROM staff")
            total_staff = cur.fetchone()['count']

            cur.execute("SELECT COUNT(*) AS count FROM wardens")
            total_wardens = cur.fetchone()['count']

            cur.execute("SELECT COUNT(*) AS count, IFNULL(SUM(capacity), 0) AS total_cap FROM rooms")
            room_row = cur.fetchone()
            total_rooms = room_row['count']
            total_capacity = int(room_row['total_cap'])

            cur.execute("SELECT COUNT(*) AS count FROM students WHERE room_id IS NOT NULL AND status = 'active'")
            occupied_beds = cur.fetchone()['count']

            cur.execute("SELECT COUNT(*) AS count FROM staff WHERE status = 'pending'")
            pending_staff = cur.fetchone()['count']

            cur.execute("SELECT COUNT(*) AS count FROM student_requests WHERE status = 'PENDING'")
            pending_requests = cur.fetchone()['count']

            cur.execute("SELECT COUNT(*) AS count FROM hostels")
            total_hostels = cur.fetchone()['count']

            stats = {
                'total_students': total_students,
                'total_staff': total_staff,
                'total_wardens': total_wardens,
                'total_rooms': total_rooms,
                'total_capacity': total_capacity,
                'occupied_beds': occupied_beds,
                'available_beds': max(0, total_capacity - occupied_beds),
                'pending_staff': pending_staff,
                'pending_requests': pending_requests,
                'total_hostels': total_hostels
            }

            # Pending requests summary
            cur.execute("""
                SELECT sr.*, s.full_name, s.student_id AS custom_student_id
                FROM student_requests sr
                JOIN students s ON sr.student_id = s.id
                WHERE sr.status = 'PENDING'
                ORDER BY sr.created_at DESC LIMIT 5
            """)
            recent_requests = cur.fetchall()

            # Hostels list
            cur.execute("SELECT * FROM hostels ORDER BY name ASC")
            hostels = cur.fetchall()

            # Recent activity logs
            cur.execute("SELECT * FROM activity_logs ORDER BY created_at DESC LIMIT 6")
            recent_logs = cur.fetchall()

        return render_template('admin/dashboard.html',
                               active_page='admin_dashboard',
                               stats=stats,
                               recent_requests=recent_requests,
                               hostels=hostels,
                               recent_logs=recent_logs)
    finally:
        conn.close()

@app.route('/admin/manage_staff')
@admin_required
def admin_manage_staff():
    """View, approve, deactivate, and assign permissions to staff."""
    conn = get_db_connection()
    try:
        with conn.cursor() as cur:
            # All staff members
            cur.execute("""
                SELECT s.*, h.name AS hostel_name
                FROM staff s
                LEFT JOIN hostels h ON s.hostel_id = h.id
                ORDER BY s.created_at DESC
            """)
            staff_list = cur.fetchall()

            # All permissions
            cur.execute("SELECT * FROM permissions ORDER BY id ASC")
            all_permissions = cur.fetchall()

            # Fetch granted permissions per staff member
            for member in staff_list:
                cur.execute("""
                    SELECT p.id, p.code, p.name FROM staff_permissions sp
                    JOIN permissions p ON sp.permission_id = p.id
                    WHERE sp.staff_id = %s
                """, (member['id'],))
                perms = cur.fetchall()
                member['permissions_list'] = perms
                member['assigned_permission_ids'] = [p['id'] for p in perms]

        return render_template('admin/manage_staff.html',
                               active_page='manage_staff',
                               staff_list=staff_list,
                               all_permissions=all_permissions)
    finally:
        conn.close()

@app.route('/admin/staff/<int:staff_id>/approve', methods=['POST'])
@admin_required
def admin_approve_staff(staff_id):
    """Approve a pending staff registration and assign default permissions."""
    conn = get_db_connection()
    try:
        with conn.cursor() as cur:
            cur.execute("UPDATE staff SET status = 'active' WHERE id = %s", (staff_id,))
            # Grant default operational permissions
            cur.execute("INSERT IGNORE INTO staff_permissions (staff_id, permission_id) VALUES (%s, 1), (%s, 2), (%s, 3), (%s, 4)",
                        (staff_id, staff_id, staff_id, staff_id))
        conn.commit()

        log_activity(conn, session['user_id'], session['custom_id'], 'admin',
                     'APPROVE_STAFF', f"Approved staff account ID {staff_id} to active.")
        flash("Staff account approved and activated with standard permissions.", "success")
    finally:
        conn.close()
    return redirect(url_for('admin_manage_staff'))

@app.route('/admin/staff/<int:staff_id>/status/<new_status>', methods=['POST'])
@admin_required
def admin_toggle_staff_status(staff_id, new_status):
    """Activate, deactivate, or suspend staff accounts."""
    if new_status not in ['active', 'inactive', 'suspended']:
        flash("Invalid account status requested.", "danger")
        return redirect(url_for('admin_manage_staff'))

    conn = get_db_connection()
    try:
        with conn.cursor() as cur:
            cur.execute("UPDATE staff SET status = %s WHERE id = %s", (new_status, staff_id))
        conn.commit()

        log_activity(conn, session['user_id'], session['custom_id'], 'admin',
                     'UPDATE_STAFF_STATUS', f"Changed staff ID {staff_id} status to {new_status}.")
        flash(f"Staff account status changed to {new_status.upper()}.", "success")
    finally:
        conn.close()
    return redirect(url_for('admin_manage_staff'))

@app.route('/admin/staff/<int:staff_id>/permissions', methods=['POST'])
@admin_required
def admin_update_staff_permissions(staff_id):
    """Update assigned fine-grained permissions for a specific staff member."""
    selected_permissions = request.form.getlist('permissions')

    conn = get_db_connection()
    try:
        with conn.cursor() as cur:
            cur.execute("DELETE FROM staff_permissions WHERE staff_id = %s", (staff_id,))
            for perm_id in selected_permissions:
                cur.execute("INSERT INTO staff_permissions (staff_id, permission_id) VALUES (%s, %s)",
                            (staff_id, int(perm_id)))
        conn.commit()

        log_activity(conn, session['user_id'], session['custom_id'], 'admin',
                     'UPDATE_PERMISSIONS', f"Updated permissions for staff ID {staff_id}.")
        flash("Staff permissions updated successfully.", "success")
    finally:
        conn.close()
    return redirect(url_for('admin_manage_staff'))

@app.route('/admin/manage_wardens')
@admin_required
def admin_manage_wardens():
    """Warden appointment and governance."""
    conn = get_db_connection()
    try:
        with conn.cursor() as cur:
            cur.execute("""
                SELECT w.*, h.name AS hostel_name, h.hostel_type
                FROM wardens w
                JOIN hostels h ON w.hostel_id = h.id
                ORDER BY w.created_at DESC
            """)
            wardens_list = cur.fetchall()

            cur.execute("SELECT * FROM hostels ORDER BY name ASC")
            hostels = cur.fetchall()

        return render_template('admin/manage_wardens.html',
                               active_page='manage_wardens',
                               wardens_list=wardens_list,
                               hostels=hostels)
    finally:
        conn.close()

@app.route('/admin/wardens/create', methods=['POST'])
@admin_required
def admin_create_warden():
    """Create a new Warden account with automatic WRD ID generation."""
    full_name = request.form.get('full_name', '').strip()
    hostel_id = request.form.get('hostel_id', '').strip()
    email = request.form.get('email', '').strip()
    phone = request.form.get('phone', '').strip()
    username = request.form.get('username', '').strip()
    password = request.form.get('password', '').strip()

    if not all([full_name, hostel_id, email, phone, username, password]):
        flash("All warden fields are mandatory.", "danger")
        return redirect(url_for('admin_manage_wardens'))

    conn = get_db_connection()
    try:
        warden_id = generate_custom_id(conn, 'warden')
        pw_hash = generate_password_hash(password)

        with conn.cursor() as cur:
            cur.execute("""
                INSERT INTO wardens (warden_id, hostel_id, username, email, password_hash, full_name, phone, status)
                VALUES (%s, %s, %s, %s, %s, %s, %s, 'active')
            """, (warden_id, hostel_id, username, email, pw_hash, full_name, phone))
        conn.commit()

        log_activity(conn, session['user_id'], session['custom_id'], 'admin',
                     'CREATE_WARDEN', f"Created warden {full_name} ({warden_id}).")
        flash(f"Warden account created successfully! Generated ID: {warden_id}", "success")
    except Exception as e:
        conn.rollback()
        flash(f"Error creating warden (username or email may already exist): {e}", "danger")
    finally:
        conn.close()

    return redirect(url_for('admin_manage_wardens'))

@app.route('/admin/wardens/<int:warden_id>/status/<new_status>', methods=['POST'])
@admin_required
def admin_toggle_warden_status(warden_id, new_status):
    """Suspend or reactivate warden accounts."""
    if new_status not in ['active', 'inactive']:
        flash("Invalid status.", "danger")
        return redirect(url_for('admin_manage_wardens'))

    conn = get_db_connection()
    try:
        with conn.cursor() as cur:
            cur.execute("UPDATE wardens SET status = %s WHERE id = %s", (new_status, warden_id))
        conn.commit()

        log_activity(conn, session['user_id'], session['custom_id'], 'admin',
                     'UPDATE_WARDEN_STATUS', f"Changed warden ID {warden_id} status to {new_status}.")
        flash(f"Warden status changed to {new_status.upper()}.", "success")
    finally:
        conn.close()
    return redirect(url_for('admin_manage_wardens'))

@app.route('/admin/manage_students')
@admin_required
def admin_manage_students():
    """Master directory of all student residents across the university."""
    conn = get_db_connection()
    try:
        with conn.cursor() as cur:
            cur.execute("""
                SELECT s.*, h.name AS hostel_name, r.room_number
                FROM students s
                JOIN hostels h ON s.hostel_id = h.id
                LEFT JOIN rooms r ON s.room_id = r.id
                ORDER BY s.created_at DESC
            """)
            students_list = cur.fetchall()

        return render_template('admin/manage_students.html',
                               active_page='manage_students',
                               students_list=students_list)
    finally:
        conn.close()

@app.route('/admin/students/<int:student_id>/reset_password', methods=['POST'])
@admin_required
def admin_reset_student_password(student_id):
    """Reset a student's password to default Student@123 with must_change_password=1."""
    conn = get_db_connection()
    try:
        temp_hash = generate_password_hash('Student@123')
        with conn.cursor() as cur:
            cur.execute("""
                UPDATE students SET password_hash = %s, must_change_password = 1
                WHERE id = %s
            """, (temp_hash, student_id))
        conn.commit()

        log_activity(conn, session['user_id'], session['custom_id'], 'admin',
                     'RESET_STUDENT_PASSWORD', f"Reset password for student ID {student_id}.")
        flash("Student password reset to default: Student@123 (Temporary flag set).", "success")
    finally:
        conn.close()
    return redirect(url_for('admin_manage_students'))

@app.route('/admin/manage_rooms')
@admin_required
def admin_manage_rooms():
    """Room inventory, capacity planning, and occupant analysis."""
    conn = get_db_connection()
    try:
        with conn.cursor() as cur:
            cur.execute("""
                SELECT r.*, h.name AS hostel_name,
                       (SELECT COUNT(*) FROM students s WHERE s.room_id = r.id AND s.status = 'active') AS occupied_count
                FROM rooms r
                JOIN hostels h ON r.hostel_id = h.id
                ORDER BY h.name ASC, r.room_number ASC
            """)
            rooms_list = cur.fetchall()

            for r in rooms_list:
                r['available_beds'] = max(0, r['capacity'] - r['occupied_count'])
                # Fetch resident names
                cur.execute("SELECT student_id, full_name FROM students WHERE room_id = %s AND status = 'active'", (r['id'],))
                r['occupants'] = cur.fetchall()

            cur.execute("SELECT * FROM hostels ORDER BY name ASC")
            hostels = cur.fetchall()

        return render_template('admin/manage_rooms.html',
                               active_page='manage_rooms',
                               rooms_list=rooms_list,
                               hostels=hostels)
    finally:
        conn.close()

@app.route('/admin/rooms/add', methods=['POST'])
@admin_required
def admin_add_room():
    """Register a new room with designated capacity and monthly fee."""
    hostel_id = request.form.get('hostel_id')
    room_number = request.form.get('room_number', '').strip().upper()
    floor = request.form.get('floor', 1)
    room_type = request.form.get('room_type', 'Three Sharing')
    capacity = int(request.form.get('capacity', 3))
    monthly_fee = float(request.form.get('monthly_fee', 5000))
    description = request.form.get('description', '')

    conn = get_db_connection()
    try:
        with conn.cursor() as cur:
            cur.execute("""
                INSERT INTO rooms (hostel_id, room_number, floor, room_type, capacity, monthly_fee, status, description)
                VALUES (%s, %s, %s, %s, %s, %s, 'available', %s)
            """, (hostel_id, room_number, floor, room_type, capacity, monthly_fee, description))
        conn.commit()

        log_activity(conn, session['user_id'], session['custom_id'], 'admin',
                     'ADD_ROOM', f"Created room {room_number} with capacity {capacity}.")
        flash(f"Room {room_number} registered successfully!", "success")
    except Exception as e:
        conn.rollback()
        flash(f"Failed to add room (room number may already exist in this hostel): {e}", "danger")
    finally:
        conn.close()

    return redirect(url_for('admin_manage_rooms'))

@app.route('/admin/rooms/<int:room_id>/delete', methods=['POST'])
@admin_required
def admin_delete_room(room_id):
    """Delete a room only when unoccupied."""
    conn = get_db_connection()
    try:
        with conn.cursor() as cur:
            cur.execute("SELECT COUNT(*) AS occ FROM students WHERE room_id = %s AND status = 'active'", (room_id,))
            if cur.fetchone()['occ'] > 0:
                flash("Cannot delete an occupied room! Please transfer or vacate students first.", "danger")
                return redirect(url_for('admin_manage_rooms'))

            cur.execute("DELETE FROM rooms WHERE id = %s", (room_id,))
        conn.commit()

        log_activity(conn, session['user_id'], session['custom_id'], 'admin',
                     'DELETE_ROOM', f"Deleted unoccupied room ID {room_id}.")
        flash("Room deleted successfully.", "success")
    finally:
        conn.close()

    return redirect(url_for('admin_manage_rooms'))

@app.route('/admin/manage_fees')
@admin_required
def admin_manage_fees():
    """Fee records, billing management, and payment receipts."""
    conn = get_db_connection()
    try:
        with conn.cursor() as cur:
            # Stats
            cur.execute("SELECT SUM(total_amount) AS total_invoiced, SUM(paid_amount) AS total_collected FROM fee_records")
            fee_stats = cur.fetchone()

            # Active students for billing dropdown
            cur.execute("SELECT id, student_id, full_name FROM students WHERE status = 'active' ORDER BY full_name ASC")
            students_list = cur.fetchall()

            # Pending fee records
            cur.execute("""
                SELECT fr.*, s.student_id, s.full_name
                FROM fee_records fr
                JOIN students s ON fr.student_id = s.id
                WHERE fr.paid_amount < fr.total_amount
                ORDER BY fr.due_date ASC
            """)
            pending_fee_records = cur.fetchall()

            # All fee records
            cur.execute("""
                SELECT fr.*, s.student_id, s.full_name
                FROM fee_records fr
                JOIN students s ON fr.student_id = s.id
                ORDER BY fr.created_at DESC
            """)
            fee_records_list = cur.fetchall()

            # Payments list
            cur.execute("""
                SELECT fp.*, s.student_id, s.full_name, fr.academic_term
                FROM fee_payments fp
                JOIN students s ON fp.student_id = s.id
                JOIN fee_records fr ON fp.fee_record_id = fr.id
                ORDER BY fp.created_at DESC LIMIT 20
            """)
            payments_list = cur.fetchall()

        return render_template('admin/manage_fees.html',
                               active_page='manage_fees',
                               fee_stats=fee_stats,
                               students_list=students_list,
                               pending_fee_records=pending_fee_records,
                               fee_records_list=fee_records_list,
                               payments_list=payments_list)
    finally:
        conn.close()

@app.route('/admin/fees/create_record', methods=['POST'])
@admin_required
def admin_create_fee_record():
    """Issue a new fee bill/invoice for an enrolled resident student."""
    student_id = request.form.get('student_id')
    academic_term = request.form.get('academic_term', 'Semester Fee')
    total_amount = float(request.form.get('total_amount', 30000))
    due_date = request.form.get('due_date')

    conn = get_db_connection()
    try:
        with conn.cursor() as cur:
            cur.execute("""
                INSERT INTO fee_records (student_id, academic_term, total_amount, paid_amount, due_date, status)
                VALUES (%s, %s, %s, 0.00, %s, 'pending')
            """, (student_id, academic_term, total_amount, due_date))
        conn.commit()

        log_activity(conn, session['user_id'], session['custom_id'], 'admin',
                     'CREATE_FEE_RECORD', f"Issued {academic_term} fee of ₹{total_amount} to student ID {student_id}.")
        flash("Hostel fee invoice issued successfully.", "success")
    finally:
        conn.close()
    return redirect(url_for('admin_manage_fees'))

@app.route('/admin/fees/record_payment', methods=['POST'])
@admin_required
def admin_record_fee_payment():
    """Record a verified manual fee transaction and generate a payment receipt."""
    fee_record_id = request.form.get('fee_record_id')
    amount_paid = float(request.form.get('amount_paid', 0))
    payment_mode = request.form.get('payment_mode', 'UPI / Bank Transfer')
    payment_date = request.form.get('payment_date')
    remarks = request.form.get('remarks', '')

    conn = get_db_connection()
    try:
        receipt_no = generate_custom_id(conn, 'receipt')

        with conn.cursor() as cur:
            cur.execute("SELECT student_id, total_amount, paid_amount FROM fee_records WHERE id = %s", (fee_record_id,))
            record = cur.fetchone()
            if not record:
                flash("Fee record not found.", "danger")
                return redirect(url_for('admin_manage_fees'))

            student_id = record['student_id']
            new_paid = float(record['paid_amount']) + amount_paid
            total_amt = float(record['total_amount'])

            new_status = 'paid' if new_paid >= total_amt else 'partial'

            cur.execute("""
                UPDATE fee_records SET paid_amount = %s, status = %s WHERE id = %s
            """, (new_paid, new_status, fee_record_id))

            cur.execute("""
                INSERT INTO fee_payments (receipt_number, fee_record_id, student_id, amount_paid, payment_mode, payment_date, recorded_by, recorded_role, remarks)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
            """, (receipt_no, fee_record_id, student_id, amount_paid, payment_mode, payment_date, session['name'], session['role'], remarks))
        conn.commit()

        log_activity(conn, session['user_id'], session['custom_id'], 'admin',
                     'RECORD_PAYMENT', f"Recorded payment ₹{amount_paid} ({receipt_no}) for student ID {student_id}.")
        flash(f"Payment recorded successfully! Receipt #{receipt_no} generated.", "success")
    finally:
        conn.close()
    return redirect(url_for('admin_manage_fees'))

@app.route('/admin/announcement/post', methods=['POST'])
@admin_required
def admin_post_announcement():
    """Broadcast an official announcement to students and staff."""
    title = request.form.get('title', '').strip()
    target_role = request.form.get('target_role', 'all')
    message = request.form.get('message', '').strip()

    conn = get_db_connection()
    try:
        with conn.cursor() as cur:
            cur.execute("""
                INSERT INTO announcements (title, message, target_role, posted_by, posted_role)
                VALUES (%s, %s, %s, %s, %s)
            """, (title, message, target_role, session['name'], session['role']))
        conn.commit()

        log_activity(conn, session['user_id'], session['custom_id'], 'admin',
                     'BROADCAST_ANNOUNCEMENT', f"Broadcasted announcement: '{title}'.")
        flash("Announcement broadcasted successfully.", "success")
    finally:
        conn.close()
    return redirect(url_for('admin_dashboard'))

@app.route('/admin/reports')
@admin_required
def admin_reports():
    """Comprehensive analytical reports and summary telemetry."""
    conn = get_db_connection()
    try:
        with conn.cursor() as cur:
            # Block by block occupancy
            cur.execute("""
                SELECT h.name AS hostel_name, h.hostel_type,
                       COUNT(r.id) AS room_count,
                       IFNULL(SUM(r.capacity), 0) AS total_capacity,
                       IFNULL((SELECT COUNT(*) FROM students s WHERE s.hostel_id = h.id AND s.room_id IS NOT NULL AND s.status = 'active'), 0) AS occupied_count
                FROM hostels h
                LEFT JOIN rooms r ON h.id = r.hostel_id
                GROUP BY h.id, h.name, h.hostel_type
            """)
            occupancy_report = cur.fetchall()

            # Revenue stats
            cur.execute("SELECT SUM(total_amount) AS total_invoiced, SUM(paid_amount) AS total_collected FROM fee_records")
            fee_report = cur.fetchone()

            # Demographics by course
            cur.execute("""
                SELECT course, COUNT(*) AS student_count
                FROM students WHERE status = 'active'
                GROUP BY course ORDER BY student_count DESC
            """)
            course_report = cur.fetchall()

            # Complaints resolution
            cur.execute("SELECT status, COUNT(*) AS count FROM student_requests GROUP BY status")
            request_stats = cur.fetchall()

        return render_template('admin/reports.html',
                               active_page='reports',
                               occupancy_report=occupancy_report,
                               fee_report=fee_report,
                               course_report=course_report,
                               request_stats=request_stats)
    finally:
        conn.close()

@app.route('/admin/activity_logs')
@admin_required
def admin_activity_logs():
    """Immutable audit trail."""
    conn = get_db_connection()
    try:
        with conn.cursor() as cur:
            cur.execute("SELECT * FROM activity_logs ORDER BY created_at DESC LIMIT 100")
            logs = cur.fetchall()
        return render_template('admin/activity_logs.html', active_page='activity_logs', logs=logs)
    finally:
        conn.close()

@app.route('/admin/change_password', methods=['GET', 'POST'])
@admin_required
def admin_change_password():
    """Change administrator password."""
    if request.method == 'POST':
        curr_pwd = request.form.get('current_password', '')
        new_pwd = request.form.get('new_password', '')
        confirm_pwd = request.form.get('confirm_password', '')

        if new_pwd != confirm_pwd:
            flash("New passwords do not match.", "danger")
            return redirect(url_for('admin_change_password'))

        conn = get_db_connection()
        try:
            with conn.cursor() as cur:
                cur.execute("SELECT password_hash FROM admins WHERE id = %s", (session['user_id'],))
                admin = cur.fetchone()

                if not admin or not check_password_hash(admin['password_hash'], curr_pwd):
                    flash("Current password is incorrect.", "danger")
                    return redirect(url_for('admin_change_password'))

                new_hash = generate_password_hash(new_pwd)
                cur.execute("UPDATE admins SET password_hash = %s WHERE id = %s", (new_hash, session['user_id']))
            conn.commit()

            log_activity(conn, session['user_id'], session['custom_id'], 'admin',
                         'CHANGE_PASSWORD', "Updated administrator password.")
            flash("Administrator password updated successfully.", "success")
        finally:
            conn.close()

    return render_template('admin/change_password.html', active_page='change_password')

# ==============================================================================
# Staff & Warden Portal
# ==============================================================================

@app.route('/staff/login', methods=['GET', 'POST'])
def staff_login():
    """Staff and Warden operations login portal."""
    if session.get('role') in ['staff', 'warden']:
        return redirect(url_for('staff_dashboard'))

    if request.method == 'POST':
        identifier = request.form.get('username', '').strip()
        password = request.form.get('password', '').strip()

        conn = get_db_connection()
        try:
            with conn.cursor() as cur:
                # 1. Try Warden login first
                cur.execute("""
                    SELECT w.*, h.name AS hostel_name FROM wardens w
                    JOIN hostels h ON w.hostel_id = h.id
                    WHERE (w.username = %s OR w.warden_id = %s) AND w.status = 'active'
                """, (identifier, identifier))
                warden = cur.fetchone()

                if warden and check_password_hash(warden['password_hash'], password):
                    session.clear()
                    session['user_id'] = warden['id']
                    session['custom_id'] = warden['warden_id']
                    session['role'] = 'warden'
                    session['name'] = warden['full_name']
                    session['hostel_id'] = warden['hostel_id']
                    session['hostel_name'] = warden['hostel_name']

                    log_activity(conn, warden['id'], warden['warden_id'], 'warden', 'WARDEN_LOGIN', 'Warden authenticated.')
                    flash(f"Welcome back, Warden {warden['full_name']}!", "success")
                    return redirect(url_for('staff_dashboard'))

                # 2. Try Staff login
                cur.execute("""
                    SELECT s.*, h.name AS hostel_name FROM staff s
                    LEFT JOIN hostels h ON s.hostel_id = h.id
                    WHERE s.username = %s OR s.staff_id = %s
                """, (identifier, identifier))
                staff_user = cur.fetchone()

                if staff_user and check_password_hash(staff_user['password_hash'], password):
                    if staff_user['status'] == 'pending':
                        flash("Your staff account is currently PENDING approval by the Main Administrator.", "warning")
                        return redirect(url_for('staff_login'))
                    elif staff_user['status'] != 'active':
                        flash(f"Your staff account is currently {staff_user['status'].upper()}. Contact system admin.", "danger")
                        return redirect(url_for('staff_login'))

                    session.clear()
                    session['user_id'] = staff_user['id']
                    session['custom_id'] = staff_user['staff_id']
                    session['role'] = 'staff'
                    session['name'] = staff_user['full_name']
                    session['hostel_id'] = staff_user['hostel_id']
                    session['hostel_name'] = staff_user['hostel_name'] or 'All Hostels'

                    log_activity(conn, staff_user['id'], staff_user['staff_id'], 'staff', 'STAFF_LOGIN', 'Staff authenticated.')
                    flash(f"Welcome, {staff_user['full_name']}!", "success")
                    return redirect(url_for('staff_dashboard'))

                flash("Invalid Staff/Warden credentials or account not found.", "danger")
        finally:
            conn.close()

    return render_template('staff/login.html')

@app.route('/staff/register', methods=['GET', 'POST'])
def staff_register():
    """Staff self-registration form. Created accounts are marked PENDING until approved."""
    conn = get_db_connection()
    try:
        if request.method == 'POST':
            full_name = request.form.get('full_name', '').strip()
            designation = request.form.get('designation', 'Hostel Assistant').strip()
            email = request.form.get('email', '').strip()
            phone = request.form.get('phone', '').strip()
            hostel_id = request.form.get('hostel_id') or None
            username = request.form.get('username', '').strip()
            password = request.form.get('password', '').strip()

            if not all([full_name, email, phone, username, password]):
                flash("Please complete all required fields.", "danger")
                return redirect(url_for('staff_register'))

            staff_id = generate_custom_id(conn, 'staff')
            pw_hash = generate_password_hash(password)

            with conn.cursor() as cur:
                cur.execute("""
                    INSERT INTO staff (staff_id, hostel_id, username, email, password_hash, full_name, phone, designation, status)
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, 'pending')
                """, (staff_id, hostel_id, username, email, pw_hash, full_name, phone, designation))
            conn.commit()

            log_activity(conn, None, staff_id, 'staff', 'STAFF_REGISTER', f"New staff application submitted by {full_name}.")
            flash(f"Registration submitted! Your generated Staff ID is {staff_id}. Please wait for Administrator approval before signing in.", "success")
            return redirect(url_for('staff_login'))

        with conn.cursor() as cur:
            cur.execute("SELECT * FROM hostels ORDER BY name ASC")
            hostels = cur.fetchall()

        return render_template('staff/register.html', hostels=hostels)
    finally:
        conn.close()

@app.route('/staff/dashboard')
@warden_or_staff_required
def staff_dashboard():
    """Operational dashboard for staff & wardens."""
    conn = get_db_connection()
    try:
        user_id = session.get('user_id')
        role = session.get('role')

        with conn.cursor() as cur:
            cur.execute("SELECT COUNT(*) AS count FROM students WHERE status = 'active'")
            total_students = cur.fetchone()['count']

            cur.execute("SELECT COUNT(*) AS count, IFNULL(SUM(capacity), 0) AS total_cap FROM rooms")
            room_row = cur.fetchone()
            total_rooms = room_row['count']
            total_capacity = int(room_row['total_cap'])

            cur.execute("SELECT COUNT(*) AS count FROM students WHERE room_id IS NOT NULL AND status = 'active'")
            occupied_beds = cur.fetchone()['count']

            cur.execute("SELECT COUNT(*) AS count FROM student_requests WHERE status = 'PENDING'")
            pending_requests = cur.fetchone()['count']

            stats = {
                'total_students': total_students,
                'total_rooms': total_rooms,
                'total_capacity': total_capacity,
                'occupied_beds': occupied_beds,
                'available_beds': max(0, total_capacity - occupied_beds),
                'pending_requests': pending_requests
            }

            # Assigned permissions for staff
            permissions = []
            if role == 'staff':
                cur.execute("""
                    SELECT p.* FROM staff_permissions sp
                    JOIN permissions p ON sp.permission_id = p.id
                    WHERE sp.staff_id = %s
                """, (user_id,))
                permissions = cur.fetchall()

            # Hostel Info if assigned
            hostel_info = None
            if session.get('hostel_id'):
                cur.execute("SELECT * FROM hostels WHERE id = %s", (session.get('hostel_id'),))
                hostel_info = cur.fetchone()

            # Pending requests
            cur.execute("""
                SELECT sr.*, s.full_name, s.student_id
                FROM student_requests sr
                JOIN students s ON sr.student_id = s.id
                WHERE sr.status = 'PENDING'
                ORDER BY sr.created_at DESC LIMIT 5
            """)
            pending_requests_list = cur.fetchall()

        return render_template('staff/dashboard.html',
                               active_page='staff_dashboard',
                               stats=stats,
                               permissions=permissions,
                               hostel_info=hostel_info,
                               pending_requests_list=pending_requests_list)
    finally:
        conn.close()

@app.route('/staff/add_student', methods=['GET', 'POST'])
@warden_or_staff_required
def staff_add_student():
    """Register a new student: auto-generates STU ID, temp password, and bed allocation."""
    if session.get('role') == 'staff' and not check_permission(session['user_id'], 'create_student'):
        flash("You lack permission to register new students. Contact system admin.", "danger")
        return redirect(url_for('staff_dashboard'))

    conn = get_db_connection()
    try:
        if request.method == 'POST':
            full_name = request.form.get('full_name', '').strip()
            gender = request.form.get('gender', 'Male')
            course = request.form.get('course', '').strip()
            email = request.form.get('email', '').strip()
            phone = request.form.get('phone', '').strip()
            emergency_contact = request.form.get('emergency_contact', '').strip()
            parent_name = request.form.get('parent_name', '').strip()
            parent_phone = request.form.get('parent_phone', '').strip()
            address = request.form.get('address', '').strip()
            hostel_id = request.form.get('hostel_id')
            room_id = request.form.get('room_id') or None

            # Generate automatic Student ID and temporary password
            student_id = generate_custom_id(conn, 'student')
            temp_password = 'Student@123'
            pw_hash = generate_password_hash(temp_password)

            with conn.cursor() as cur:
                # Capacity check if room selected
                if room_id:
                    cur.execute("""
                        SELECT capacity,
                               (SELECT COUNT(*) FROM students WHERE room_id = %s AND status = 'active') AS occupied
                        FROM rooms WHERE id = %s
                    """, (room_id, room_id))
                    room_check = cur.fetchone()
                    if room_check and room_check['occupied'] >= room_check['capacity']:
                        flash("Selected room is already at full capacity! Please choose another room.", "danger")
                        return redirect(url_for('staff_add_student'))

                # Insert student record
                cur.execute("""
                    INSERT INTO students (
                        student_id, hostel_id, room_id, username, email, password_hash,
                        full_name, phone, gender, course, parent_name, parent_phone,
                        address, emergency_contact, must_change_password, status
                    ) VALUES (
                        %s, %s, %s, %s, %s, %s,
                        %s, %s, %s, %s, %s, %s,
                        %s, %s, 1, 'active'
                    )
                """, (
                    student_id, hostel_id, room_id, student_id, email, pw_hash,
                    full_name, phone, gender, course, parent_name, parent_phone,
                    address, emergency_contact
                ))
                new_student_pk = cur.lastrowid

                # Record room allocation if assigned
                if room_id:
                    cur.execute("""
                        INSERT INTO room_allocations (student_id, room_id, allocated_by, allocated_role, start_date, status)
                        VALUES (%s, %s, %s, %s, CURDATE(), 'active')
                    """, (new_student_pk, room_id, session['name'], session['role']))

                # Issue initial semester fee record
                cur.execute("""
                    INSERT INTO fee_records (student_id, academic_term, total_amount, paid_amount, due_date, status)
                    VALUES (%s, 'Academic Term 2026-27 (Sem 1)', 30000.00, 0.00, DATE_ADD(CURDATE(), INTERVAL 30 DAY), 'pending')
                """, (new_student_pk,))

            conn.commit()

            log_activity(conn, session['user_id'], session['custom_id'], session['role'],
                         'REGISTER_STUDENT', f"Enrolled student {full_name} ({student_id}).")
            flash(f"Resident enrolled successfully! Student ID: {student_id} | Temporary Password: {temp_password}", "success")
            return redirect(url_for('staff_students'))

        with conn.cursor() as cur:
            cur.execute("SELECT * FROM hostels ORDER BY name ASC")
            hostels = cur.fetchall()

            # Rooms with free beds
            cur.execute("""
                SELECT r.*, h.name AS hostel_name,
                       (r.capacity - (SELECT COUNT(*) FROM students s WHERE s.room_id = r.id AND s.status = 'active')) AS available_beds
                FROM rooms r
                JOIN hostels h ON r.hostel_id = h.id
                HAVING available_beds > 0
                ORDER BY h.name ASC, r.room_number ASC
            """)
            available_rooms = cur.fetchall()

        return render_template('staff/add_student.html',
                               active_page='add_student',
                               hostels=hostels,
                               available_rooms=available_rooms)
    finally:
        conn.close()

@app.route('/staff/students')
@warden_or_staff_required
def staff_students():
    """List resident students and provide password resets."""
    conn = get_db_connection()
    try:
        with conn.cursor() as cur:
            cur.execute("""
                SELECT s.*, h.name AS hostel_name, r.room_number
                FROM students s
                JOIN hostels h ON s.hostel_id = h.id
                LEFT JOIN rooms r ON s.room_id = r.id
                ORDER BY s.created_at DESC
            """)
            students_list = cur.fetchall()

        return render_template('staff/student_list.html',
                               active_page='student_list',
                               students_list=students_list)
    finally:
        conn.close()

@app.route('/staff/students/<int:student_id>/reset_password', methods=['POST'])
@warden_or_staff_required
def staff_reset_student_password(student_id):
    """Reset a student's password to default Student@123."""
    conn = get_db_connection()
    try:
        temp_hash = generate_password_hash('Student@123')
        with conn.cursor() as cur:
            cur.execute("""
                UPDATE students SET password_hash = %s, must_change_password = 1
                WHERE id = %s
            """, (temp_hash, student_id))
        conn.commit()

        log_activity(conn, session['user_id'], session['custom_id'], session['role'],
                     'RESET_STUDENT_PASSWORD', f"Staff reset password for student ID {student_id}.")
        flash("Student temporary password reset to Student@123.", "success")
    finally:
        conn.close()
    return redirect(url_for('staff_students'))

@app.route('/staff/room_allocation', methods=['GET', 'POST'])
@app.route('/staff/allocate_room', methods=['POST'], endpoint='staff_allocate_room')
@warden_or_staff_required
def staff_room_allocation():
    """Interactive bed allocation and room transfer module."""
    if session.get('role') == 'staff' and not check_permission(session['user_id'], 'allocate_rooms'):
        flash("You lack permission to allocate or transfer rooms. Contact admin.", "danger")
        return redirect(url_for('staff_dashboard'))

    conn = get_db_connection()
    try:
        if request.method == 'POST':
            student_id = request.form.get('student_id')
            target_room_id = request.form.get('target_room_id')

            if not student_id:
                flash("Please select a student resident.", "danger")
                return redirect(url_for('staff_room_allocation'))

            with conn.cursor() as cur:
                # Fetch student information
                cur.execute("SELECT id, student_id, full_name, room_id, hostel_id FROM students WHERE id = %s", (student_id,))
                student = cur.fetchone()

                if not student:
                    flash("Selected student record not found.", "danger")
                    return redirect(url_for('staff_room_allocation'))

                # Handling vacate / remove bed assignment
                if target_room_id == 'vacate':
                    cur.execute("""
                        UPDATE room_allocations SET status = 'vacated', end_date = CURDATE()
                        WHERE student_id = %s AND status = 'active'
                    """, (student_id,))
                    cur.execute("UPDATE students SET room_id = NULL WHERE id = %s", (student_id,))
                    conn.commit()

                    log_activity(conn, session['user_id'], session['custom_id'], session['role'],
                                 'VACATE_BED', f"Vacated bed for resident {student['full_name']} ({student['student_id']}).")
                    flash(f"Resident {student['full_name']} bed allocation vacated successfully.", "success")
                    return redirect(url_for('staff_room_allocation'))

                if not target_room_id:
                    flash("Please select a target room for allocation.", "danger")
                    return redirect(url_for('staff_room_allocation'))

                # Check if already in target room
                if student['room_id'] and str(student['room_id']) == str(target_room_id):
                    flash(f"Resident {student['full_name']} is already accommodated in this room.", "info")
                    return redirect(url_for('staff_room_allocation'))

                # Capacity check on target room (excluding this student if re-allocating)
                cur.execute("""
                    SELECT r.id, r.room_number, r.hostel_id, r.capacity, h.name AS hostel_name,
                           (SELECT COUNT(*) FROM students s WHERE s.room_id = r.id AND s.status = 'active' AND s.id != %s) AS other_occupied
                    FROM rooms r
                    JOIN hostels h ON r.hostel_id = h.id
                    WHERE r.id = %s
                """, (student_id, target_room_id))
                room_check = cur.fetchone()

                if not room_check:
                    flash("Target room does not exist.", "danger")
                    return redirect(url_for('staff_room_allocation'))

                if int(room_check['other_occupied']) >= int(room_check['capacity']):
                    flash(f"Room {room_check['room_number']} ({room_check['hostel_name']}) is already at full capacity ({room_check['capacity']} beds). Cannot exceed limit.", "danger")
                    return redirect(url_for('staff_room_allocation'))

                # Mark previous active allocation as transferred
                cur.execute("""
                    UPDATE room_allocations SET status = 'transferred', end_date = CURDATE()
                    WHERE student_id = %s AND status = 'active'
                """, (student_id,))

                # Update student's room AND hostel
                cur.execute("""
                    UPDATE students SET room_id = %s, hostel_id = %s WHERE id = %s
                """, (target_room_id, room_check['hostel_id'], student_id))

                # Create new allocation record
                cur.execute("""
                    INSERT INTO room_allocations (student_id, room_id, allocated_by, allocated_role, start_date, status)
                    VALUES (%s, %s, %s, %s, CURDATE(), 'active')
                """, (student_id, target_room_id, session['name'], session['role']))
            conn.commit()

            log_activity(conn, session['user_id'], session['custom_id'], session['role'],
                         'ALLOCATE_ROOM', f"Allocated resident {student['full_name']} ({student['student_id']}) to Room {room_check['room_number']} ({room_check['hostel_name']}).")
            flash(f"Resident {student['full_name']} successfully allocated to Room {room_check['room_number']} ({room_check['hostel_name']})!", "success")
            return redirect(url_for('staff_room_allocation'))

        with conn.cursor() as cur:
            # Active students list for allocation dropdown
            cur.execute("""
                SELECT s.id, s.student_id, s.full_name, s.gender, r.room_number, h.name AS hostel_name
                FROM students s
                JOIN hostels h ON s.hostel_id = h.id
                LEFT JOIN rooms r ON s.room_id = r.id
                WHERE s.status = 'active'
                ORDER BY s.full_name ASC
            """)
            all_students = cur.fetchall()

            # Rooms with availability
            cur.execute("""
                SELECT r.*, h.name AS hostel_name,
                       (r.capacity - (SELECT COUNT(*) FROM students s WHERE s.room_id = r.id AND s.status = 'active')) AS available_beds
                FROM rooms r
                JOIN hostels h ON r.hostel_id = h.id
                HAVING available_beds > 0
                ORDER BY h.name ASC, r.room_number ASC
            """)
            available_rooms = cur.fetchall()

            # All rooms with visual bed slots and occupant details
            cur.execute("""
                SELECT r.*, h.name AS hostel_name,
                       (SELECT COUNT(*) FROM students s WHERE s.room_id = r.id AND s.status = 'active') AS occupied_count
                FROM rooms r
                JOIN hostels h ON r.hostel_id = h.id
                ORDER BY h.name ASC, r.room_number ASC
            """)
            rooms_with_occupants = cur.fetchall()

            for r in rooms_with_occupants:
                r['available_beds'] = max(0, r['capacity'] - r['occupied_count'])
                cur.execute("SELECT student_id, full_name FROM students WHERE room_id = %s AND status = 'active'", (r['id'],))
                r['occupants'] = cur.fetchall()

        return render_template('staff/room_allocation.html',
                               active_page='room_allocation',
                               all_students=all_students,
                               available_rooms=available_rooms,
                               rooms_with_occupants=rooms_with_occupants)
    finally:
        conn.close()

@app.route('/staff/fee_management')
@warden_or_staff_required
def staff_fee_management():
    """Fee collection and receipt recording interface."""
    if session.get('role') == 'staff' and not check_permission(session['user_id'], 'manage_fees'):
        flash("You lack permission to manage fees. Contact admin.", "danger")
        return redirect(url_for('staff_dashboard'))

    conn = get_db_connection()
    try:
        with conn.cursor() as cur:
            # Pending fee records
            cur.execute("""
                SELECT fr.*, s.student_id, s.full_name
                FROM fee_records fr
                JOIN students s ON fr.student_id = s.id
                WHERE fr.paid_amount < fr.total_amount
                ORDER BY fr.due_date ASC
            """)
            pending_records = cur.fetchall()

            # Recent payments
            cur.execute("""
                SELECT fp.*, s.student_id, s.full_name
                FROM fee_payments fp
                JOIN students s ON fp.student_id = s.id
                ORDER BY fp.created_at DESC LIMIT 15
            """)
            recent_payments = cur.fetchall()

        return render_template('staff/fee_management.html',
                               active_page='fee_management',
                               pending_records=pending_records,
                               recent_payments=recent_payments)
    finally:
        conn.close()

@app.route('/staff/fees/record_payment', methods=['POST'])
@warden_or_staff_required
def staff_record_payment():
    """Record payment receipt from staff portal."""
    if session.get('role') == 'staff' and not check_permission(session['user_id'], 'manage_fees'):
        flash("Unauthorized action.", "danger")
        return redirect(url_for('staff_dashboard'))

    fee_record_id = request.form.get('fee_record_id')
    amount_paid = float(request.form.get('amount_paid', 0))
    payment_mode = request.form.get('payment_mode', 'UPI / Bank Transfer')
    payment_date = request.form.get('payment_date')
    remarks = request.form.get('remarks', '')

    conn = get_db_connection()
    try:
        receipt_no = generate_custom_id(conn, 'receipt')

        with conn.cursor() as cur:
            cur.execute("SELECT student_id, total_amount, paid_amount FROM fee_records WHERE id = %s", (fee_record_id,))
            record = cur.fetchone()
            if not record:
                flash("Fee invoice not found.", "danger")
                return redirect(url_for('staff_fee_management'))

            student_id = record['student_id']
            new_paid = float(record['paid_amount']) + amount_paid
            total_amt = float(record['total_amount'])
            new_status = 'paid' if new_paid >= total_amt else 'partial'

            cur.execute("UPDATE fee_records SET paid_amount = %s, status = %s WHERE id = %s", (new_paid, new_status, fee_record_id))
            cur.execute("""
                INSERT INTO fee_payments (receipt_number, fee_record_id, student_id, amount_paid, payment_mode, payment_date, recorded_by, recorded_role, remarks)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
            """, (receipt_no, fee_record_id, student_id, amount_paid, payment_mode, payment_date, session['name'], session['role'], remarks))
        conn.commit()

        log_activity(conn, session['user_id'], session['custom_id'], session['role'],
                     'RECORD_PAYMENT', f"Recorded payment ₹{amount_paid} ({receipt_no}) for student ID {student_id}.")
        flash(f"Payment recorded! Receipt #{receipt_no} generated.", "success")
    finally:
        conn.close()
    return redirect(url_for('staff_fee_management'))

@app.route('/staff/requests')
@warden_or_staff_required
def staff_requests():
    """Review student room changes, complaints, and maintenance requests."""
    conn = get_db_connection()
    try:
        with conn.cursor() as cur:
            cur.execute("""
                SELECT sr.*, s.full_name, s.student_id, r.room_number
                FROM student_requests sr
                JOIN students s ON sr.student_id = s.id
                LEFT JOIN rooms r ON s.room_id = r.id
                ORDER BY FIELD(sr.status, 'PENDING', 'APPROVED', 'COMPLETED', 'REJECTED'), sr.created_at DESC
            """)
            requests_list = cur.fetchall()

        return render_template('staff/requests.html',
                               active_page='staff_requests',
                               requests_list=requests_list)
    finally:
        conn.close()

@app.route('/staff/requests/<int:request_id>/process', methods=['POST'])
@warden_or_staff_required
def staff_process_request(request_id):
    """Update student ticket status and attach official remarks."""
    if session.get('role') == 'staff' and not check_permission(session['user_id'], 'process_requests'):
        flash("You lack permission to process student requests. Contact admin.", "danger")
        return redirect(url_for('staff_requests'))

    new_status = request.form.get('status', 'PENDING')
    staff_remarks = request.form.get('staff_remarks', '').strip()

    conn = get_db_connection()
    try:
        with conn.cursor() as cur:
            cur.execute("""
                UPDATE student_requests
                SET status = %s, staff_remarks = %s, processed_by = %s, processed_role = %s
                WHERE id = %s
            """, (new_status, staff_remarks, session['name'], session['role'], request_id))
        conn.commit()

        log_activity(conn, session['user_id'], session['custom_id'], session['role'],
                     'PROCESS_REQUEST', f"Updated ticket ID {request_id} to {new_status}.")
        flash(f"Ticket status updated to {new_status} with your official remarks.", "success")
    finally:
        conn.close()
    return redirect(url_for('staff_requests'))

@app.route('/staff/change_password', methods=['GET', 'POST'])
@warden_or_staff_required
def staff_change_password():
    """Staff/Warden personal password change."""
    if request.method == 'POST':
        curr_pwd = request.form.get('current_password', '')
        new_pwd = request.form.get('new_password', '')
        confirm_pwd = request.form.get('confirm_password', '')

        if new_pwd != confirm_pwd:
            flash("New passwords do not match.", "danger")
            return redirect(url_for('staff_change_password'))

        role = session.get('role')
        table = 'wardens' if role == 'warden' else 'staff'

        conn = get_db_connection()
        try:
            with conn.cursor() as cur:
                cur.execute(f"SELECT password_hash FROM {table} WHERE id = %s", (session['user_id'],))
                user = cur.fetchone()

                if not user or not check_password_hash(user['password_hash'], curr_pwd):
                    flash("Current password is incorrect.", "danger")
                    return redirect(url_for('staff_change_password'))

                new_hash = generate_password_hash(new_pwd)
                cur.execute(f"UPDATE {table} SET password_hash = %s WHERE id = %s", (new_hash, session['user_id']))
            conn.commit()

            log_activity(conn, session['user_id'], session['custom_id'], role,
                         'CHANGE_PASSWORD', f"Updated {role} account password.")
            flash("Password updated successfully.", "success")
        finally:
            conn.close()

    return render_template('staff/change_password.html', active_page='change_password')

# ==============================================================================
# Student Resident Portal
# ==============================================================================

@app.route('/student/login', methods=['GET', 'POST'])
def student_login():
    """Dedicated student portal login."""
    if session.get('role') == 'student':
        return redirect(url_for('student_dashboard'))

    if request.method == 'POST':
        identifier = request.form.get('username', '').strip()
        password = request.form.get('password', '').strip()

        conn = get_db_connection()
        try:
            with conn.cursor() as cur:
                cur.execute("""
                    SELECT * FROM students
                    WHERE (student_id = %s OR username = %s) AND status = 'active'
                """, (identifier, identifier))
                student = cur.fetchone()

            if student and check_password_hash(student['password_hash'], password):
                session.clear()
                session['user_id'] = student['id']
                session['custom_id'] = student['student_id']
                session['role'] = 'student'
                session['name'] = student['full_name']
                session['must_change_password'] = bool(student['must_change_password'])

                log_activity(conn, student['id'], student['student_id'], 'student', 'STUDENT_LOGIN', 'Student signed in.')

                if student['must_change_password']:
                    flash("Welcome! Since this is your temporary credentials, please set your personal password.", "info")
                    return redirect(url_for('student_change_password'))

                flash(f"Welcome back, {student['full_name']}!", "success")
                return redirect(url_for('student_dashboard'))
            else:
                flash("Invalid Student ID or password. Student accounts are created by hostel staff.", "danger")
        finally:
            conn.close()

    return render_template('student/login.html')

@app.route('/student/dashboard')
@student_required
def student_dashboard():
    """Student resident dashboard: room sharing, fees, notices, requests."""
    conn = get_db_connection()
    try:
        user_id = session.get('user_id')
        with conn.cursor() as cur:
            # Student profile info
            cur.execute("""
                SELECT s.*, h.name AS hostel_name, r.room_number, r.room_type, r.capacity, r.floor
                FROM students s
                JOIN hostels h ON s.hostel_id = h.id
                LEFT JOIN rooms r ON s.room_id = r.id
                WHERE s.id = %s
            """, (user_id,))
            student = cur.fetchone()

            # Roommates sharing the same room
            roommates = []
            room = None
            if student['room_id']:
                cur.execute("""
                    SELECT r.*,
                           (SELECT COUNT(*) FROM students WHERE room_id = r.id AND status = 'active') AS occupied_count
                    FROM rooms r WHERE r.id = %s
                """, (student['room_id'],))
                room = cur.fetchone()

                cur.execute("""
                    SELECT student_id, full_name, course, phone
                    FROM students
                    WHERE room_id = %s AND id != %s AND status = 'active'
                """, (student['room_id'], user_id))
                roommates = cur.fetchall()

            # Active fee record
            cur.execute("""
                SELECT * FROM fee_records
                WHERE student_id = %s
                ORDER BY created_at DESC LIMIT 1
            """, (user_id,))
            fee_record = cur.fetchone()

            # Announcements for students
            cur.execute("""
                SELECT * FROM announcements
                WHERE target_role IN ('all', 'students') AND (hostel_id IS NULL OR hostel_id = %s)
                ORDER BY created_at DESC LIMIT 3
            """, (student['hostel_id'],))
            recent_notices = cur.fetchall()

            # Submitted requests
            cur.execute("""
                SELECT * FROM student_requests
                WHERE student_id = %s
                ORDER BY created_at DESC LIMIT 4
            """, (user_id,))
            my_requests = cur.fetchall()

        return render_template('student/dashboard.html',
                               active_page='student_dashboard',
                               student=student,
                               room=room,
                               roommates=roommates,
                               fee_record=fee_record,
                               recent_notices=recent_notices,
                               my_requests=my_requests)
    finally:
        conn.close()

@app.route('/student/profile')
@student_required
def student_profile():
    """View personal profile details."""
    conn = get_db_connection()
    try:
        with conn.cursor() as cur:
            cur.execute("""
                SELECT s.*, h.name AS hostel_name, r.room_number
                FROM students s
                JOIN hostels h ON s.hostel_id = h.id
                LEFT JOIN rooms r ON s.room_id = r.id
                WHERE s.id = %s
            """, (session['user_id'],))
            student = cur.fetchone()

        return render_template('student/profile.html',
                               active_page='student_profile',
                               student=student)
    finally:
        conn.close()

@app.route('/student/room_details')
@student_required
def student_room_details():
    """Inspect allocated room, monthly fee, and fellow roommates."""
    conn = get_db_connection()
    try:
        user_id = session['user_id']
        with conn.cursor() as cur:
            cur.execute("""
                SELECT s.*, h.name AS hostel_name
                FROM students s
                JOIN hostels h ON s.hostel_id = h.id
                WHERE s.id = %s
            """, (user_id,))
            student = cur.fetchone()

            room = None
            roommates = []
            if student['room_id']:
                cur.execute("""
                    SELECT r.*,
                           (SELECT COUNT(*) FROM students WHERE room_id = r.id AND status = 'active') AS occupied_count
                    FROM rooms r WHERE r.id = %s
                """, (student['room_id'],))
                room = cur.fetchone()
                if room:
                    room['available_beds'] = max(0, room['capacity'] - room['occupied_count'])

                cur.execute("""
                    SELECT student_id, full_name, course, phone
                    FROM students
                    WHERE room_id = %s AND id != %s AND status = 'active'
                """, (student['room_id'], user_id))
                roommates = cur.fetchall()

        return render_template('student/room_details.html',
                               active_page='room_details',
                               student=student,
                               room=room,
                               roommates=roommates)
    finally:
        conn.close()

@app.route('/student/fees')
@student_required
def student_fee_details():
    """View hostel fee breakdown and balance."""
    conn = get_db_connection()
    try:
        user_id = session['user_id']
        with conn.cursor() as cur:
            cur.execute("SELECT * FROM fee_records WHERE student_id = %s ORDER BY created_at DESC", (user_id,))
            fee_records = cur.fetchall()

            total_invoiced = sum(float(f['total_amount']) for f in fee_records)
            total_paid = sum(float(f['paid_amount']) for f in fee_records)

        return render_template('student/fee_details.html',
                               active_page='fee_details',
                               fee_records=fee_records,
                               total_invoiced=total_invoiced,
                               total_paid=total_paid)
    finally:
        conn.close()

@app.route('/student/payment_history')
@student_required
def student_payment_history():
    """View verified payment receipts."""
    conn = get_db_connection()
    try:
        user_id = session['user_id']
        with conn.cursor() as cur:
            cur.execute("""
                SELECT fp.*, fr.academic_term
                FROM fee_payments fp
                JOIN fee_records fr ON fp.fee_record_id = fr.id
                WHERE fp.student_id = %s
                ORDER BY fp.created_at DESC
            """, (user_id,))
            payments = cur.fetchall()

        return render_template('student/payment_history.html',
                               active_page='payment_history',
                               payments=payments)
    finally:
        conn.close()

@app.route('/student/notices')
@student_required
def student_notices():
    """View hostel bulletin announcements."""
    conn = get_db_connection()
    try:
        user_id = session['user_id']
        with conn.cursor() as cur:
            cur.execute("SELECT hostel_id FROM students WHERE id = %s", (user_id,))
            st = cur.fetchone()
            hostel_id = st['hostel_id'] if st else None

            cur.execute("""
                SELECT * FROM announcements
                WHERE target_role IN ('all', 'students') AND (hostel_id IS NULL OR hostel_id = %s)
                ORDER BY created_at DESC
            """, (hostel_id,))
            notices = cur.fetchall()

        return render_template('student/notices.html',
                               active_page='notices',
                               notices=notices)
    finally:
        conn.close()

@app.route('/student/requests', methods=['GET', 'POST'])
@student_required
def student_requests():
    """Submit maintenance complaints and room-change requests."""
    user_id = session['user_id']
    conn = get_db_connection()
    try:
        if request.method == 'POST':
            category = request.form.get('category', 'general')
            priority = request.form.get('priority', 'medium')
            preferred_room_type = request.form.get('preferred_room_type') or None
            title = request.form.get('title', '').strip()
            description = request.form.get('description', '').strip()

            if not title or not description:
                flash("Please supply both a title and description.", "danger")
                return redirect(url_for('student_requests'))

            req_id = generate_custom_id(conn, 'request')

            with conn.cursor() as cur:
                cur.execute("""
                    INSERT INTO student_requests (
                        request_id, student_id, category, title, description,
                        preferred_room_type, priority, status
                    ) VALUES (%s, %s, %s, %s, %s, %s, %s, 'PENDING')
                """, (req_id, user_id, category, title, description, preferred_room_type, priority))
            conn.commit()

            log_activity(conn, user_id, session['custom_id'], 'student',
                         'SUBMIT_REQUEST', f"Submitted {category} ticket ({req_id}): '{title}'.")
            flash(f"Ticket submitted successfully! Reference: {req_id}", "success")
            return redirect(url_for('student_requests'))

        with conn.cursor() as cur:
            cur.execute("""
                SELECT * FROM student_requests
                WHERE student_id = %s
                ORDER BY created_at DESC
            """, (user_id,))
            requests_list = cur.fetchall()

        return render_template('student/requests.html',
                               active_page='student_requests',
                               requests_list=requests_list)
    finally:
        conn.close()

@app.route('/student/change_password', methods=['GET', 'POST'])
@student_required
def student_change_password():
    """Student password update (satisfies mandatory first-login password change)."""
    if request.method == 'POST':
        curr_pwd = request.form.get('current_password', '')
        new_pwd = request.form.get('new_password', '')
        confirm_pwd = request.form.get('confirm_password', '')

        if new_pwd != confirm_pwd:
            flash("New passwords do not match.", "danger")
            return redirect(url_for('student_change_password'))

        conn = get_db_connection()
        try:
            with conn.cursor() as cur:
                cur.execute("SELECT password_hash FROM students WHERE id = %s", (session['user_id'],))
                student = cur.fetchone()

                if not student or not check_password_hash(student['password_hash'], curr_pwd):
                    flash("Current / temporary password is incorrect.", "danger")
                    return redirect(url_for('student_change_password'))

                new_hash = generate_password_hash(new_pwd)
                cur.execute("""
                    UPDATE students
                    SET password_hash = %s, must_change_password = 0
                    WHERE id = %s
                """, (new_hash, session['user_id']))
            conn.commit()

            session['must_change_password'] = False
            log_activity(conn, session['user_id'], session['custom_id'], 'student',
                         'CHANGE_PASSWORD', "Student set personal password.")
            flash("Your personal password has been saved successfully!", "success")
            return redirect(url_for('student_dashboard'))
        finally:
            conn.close()

    return render_template('student/change_password.html', active_page='change_password')

# ==============================================================================
# Application Entry Point
# ==============================================================================

if __name__ == '__main__':
    print("=" * 65)
    print(" SmartStay - Advanced Hostel Management System")
    print(" Running on Flask + PyMySQL + MySQL (XAMPP)")
    print(" URL: http://127.0.0.1:5000")
    print("=" * 65)
    app.run(host='127.0.0.1', port=5000, debug=True)
